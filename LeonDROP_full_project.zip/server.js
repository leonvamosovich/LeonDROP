const express=require("express");
const path=require("path");
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"CHANGE_THIS_SECRET_IN_PRODUCTION";
const db=new Database(path.join(__dirname,"leondrop.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 gold INTEGER NOT NULL DEFAULT 1,
 promo_used INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS skins(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 rarity TEXT NOT NULL,
 price INTEGER NOT NULL,
 emoji TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 skin_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(skin_id) REFERENCES skins(id)
);
`);

const seed=[
["AKR — Dragon","Legendary",75,"🔫"],["M4 — Samurai","Arcane",95,"🔫"],
["AWM — Phoenix","Legendary",120,"🎯"],["USP — Cyber","Rare",25,"🔫"],
["G22 — Neon","Epic",40,"🔫"],["M4A1 — Demonic","Epic",68,"🔫"],
["AKR12 — Pixel","Rare",35,"🔫"],["MP7 — Space","Rare",30,"🔫"],
["FAMAS — Fury","Epic",55,"🔫"],["Karambit — Gold","Arcane",150,"🔪"],
["Butterfly — Fade","Arcane",180,"🦋"],["M9 Bayonet — Night","Legendary",110,"🔪"],
["Kunai — Crimson","Epic",70,"🔪"],["Dagger — Neon","Rare",45,"🗡️"]
];
if(db.prepare("SELECT COUNT(*) n FROM skins").get().n===0){
 const ins=db.prepare("INSERT INTO skins(name,rarity,price,emoji) VALUES(?,?,?,?)");
 const tx=db.transaction(()=>seed.forEach(x=>ins.run(...x)));tx();
}

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){
 const h=req.headers.authorization||"";
 if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Требуется вход"});
 try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}
 catch{return res.status(401).json({error:"Сессия истекла"})}
}
function token(u){return jwt.sign({id:u.id,username:u.username},JWT_SECRET,{expiresIn:"7d"})}
function userState(id){
 const u=db.prepare("SELECT id,username,gold,created_at FROM users WHERE id=?").get(id);
 const inv=db.prepare(`SELECT i.id inventory_id,s.id,name,rarity,price,emoji
 FROM inventory i JOIN skins s ON s.id=i.skin_id WHERE i.user_id=? ORDER BY i.id DESC`).all(id);
 return {user:u,inventory:inv};
}
function rarityLevel(r){return {Common:0,Uncommon:1,Rare:2,Epic:3,Legendary:4,Arcane:5}[r]??0}
function chanceFor(a,b){
 const d=rarityLevel(b.rarity)-rarityLevel(a.rarity);
 const ranges={0:[65,92],1:[45,60],2:[25,40],3:[15,25],4:[8,15],5:[5,10]};
 const [lo,hi]=ranges[Math.max(0,Math.min(5,d))];
 return lo+crypto.randomInt(hi-lo+1);
}

app.post("/api/register",async(req,res)=>{
 const {username,password}=req.body||{};
 if(!username||!password||username.length<3||password.length<6) return res.status(400).json({error:"Имя от 3 символов, пароль от 6"});
 try{
  const hash=await bcrypt.hash(password,12);
  const r=db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username,hash);
  const u=db.prepare("SELECT * FROM users WHERE id=?").get(r.lastInsertRowid);
  res.json({token:token(u),...userState(u.id)});
 }catch(e){res.status(409).json({error:"Такое имя уже занято"})}
});
app.post("/api/login",async(req,res)=>{
 const {username,password}=req.body||{};
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(username||"");
 if(!u||!(await bcrypt.compare(password||"",u.password_hash))) return res.status(401).json({error:"Неверный логин или пароль"});
 res.json({token:token(u),...userState(u.id)});
});
app.get("/api/me",auth,(req,res)=>res.json(userState(req.user.id)));
app.get("/api/skins",(req,res)=>res.json(db.prepare("SELECT * FROM skins ORDER BY price").all()));
app.post("/api/shop/buy",auth,(req,res)=>{
 const s=db.prepare("SELECT * FROM skins WHERE id=?").get(req.body.skinId);
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
 if(!s)return res.status(404).json({error:"Скин не найден"});
 if(u.gold<s.price)return res.status(400).json({error:"Недостаточно Gold"});
 const tx=db.transaction(()=>{db.prepare("UPDATE users SET gold=gold-? WHERE id=?").run(s.price,u.id);db.prepare("INSERT INTO inventory(user_id,skin_id) VALUES(?,?)").run(u.id,s.id)});
 tx();res.json(userState(u.id));
});
app.post("/api/upgrade",auth,(req,res)=>{
 const inv=db.prepare(`SELECT i.id inventory_id,s.* FROM inventory i JOIN skins s ON s.id=i.skin_id WHERE i.id=? AND i.user_id=?`).get(req.body.inventoryId,req.user.id);
 const target=db.prepare("SELECT * FROM skins WHERE id=?").get(req.body.targetSkinId);
 if(!inv||!target)return res.status(400).json({error:"Выбери исходный и целевой скин"});
 if(inv.skin_id===target.id)return res.status(400).json({error:"Цель должна отличаться"});
 const chance=chanceFor(inv,target);
 const win=crypto.randomInt(0,10000)<chance*100;
 const tx=db.transaction(()=>{
  db.prepare("DELETE FROM inventory WHERE id=?").run(inv.inventory_id);
  if(win) db.prepare("INSERT INTO inventory(user_id,skin_id) VALUES(?,?)").run(req.user.id,target.id);
 });
 tx();
 res.json({win,chance,result:win?"WIN":"LOSE",target:win?target:null,...userState(req.user.id)});
});
app.post("/api/promo",auth,(req,res)=>{
 const code=String(req.body.code||"").trim().toUpperCase();
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
 if(code!=="DROP67LEON")return res.status(400).json({error:"Неверный промокод"});
 if(u.promo_used)return res.status(400).json({error:"Промокод уже использован"});
 db.prepare("UPDATE users SET gold=gold+67,promo_used=1 WHERE id=?").run(u.id);
 res.json(userState(u.id));
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>console.log(`LeonDROP: http://localhost:${PORT}`));
